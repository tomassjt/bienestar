import { Component } from '@angular/core';

@Component({
  selector: 'demographic-icon',
  templateUrl: './demographic-icon.component.html',
  styleUrls: ['./demographic-icon.component.css']
})
export class DemographicIconComponent {

}
