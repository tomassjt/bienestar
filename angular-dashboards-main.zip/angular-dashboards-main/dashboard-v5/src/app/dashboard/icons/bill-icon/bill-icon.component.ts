import { Component } from '@angular/core';

@Component({
  selector: 'bill-icon',
  templateUrl: './bill-icon.component.html',
  styleUrls: ['./bill-icon.component.css']
})
export class BillIconComponent {

}
