import { Component } from '@angular/core';

@Component({
  selector: 'analytic-icon',
  templateUrl: './analytic-icon.component.html',
  styleUrls: ['./analytic-icon.component.css']
})
export class AnalyticIconComponent {

}
