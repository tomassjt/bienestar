import { Component } from '@angular/core';

@Component({
  selector: 'monitoring-icon',
  templateUrl: './monitoring-icon.component.html',
  styleUrls: ['./monitoring-icon.component.css']
})
export class MonitoringIconComponent {

}
