# Salvia-kit Angular Dashboards

![Salvia-kit Dashboard v1](https://www.salvia-kit.com/images/dashboards/dashv1.png)

![Salvia-kit Dashboard v2](https://www.salvia-kit.com/images/dashboards/dashv2.jpg)

![Salvia-kit Dashboard v3](https://www.salvia-kit.com/images/dashboards/dashv3.png)

![Salvia-kit Dashboard v4](https://www.salvia-kit.com/images/dashboards/dashv4.jpg)

![Salvia-kit Dashboard v5](https://www.salvia-kit.com/images/dashboards/dashv5.jpg)

![Salvia-kit Dashboard v6](https://www.salvia-kit.com/images/dashboards/dashv6.jpg)

![Salvia-kit Dashboard v7](https://www.salvia-kit.com/images/dashboards/dashv7.jpg)

![Salvia-kit Dashboard v8](https://www.salvia-kit.com/images/dashboards/dashv8.jpg)

![Salvia-kit Dashboard v9](https://www.salvia-kit.com/images/dashboards/dashv9.png)
