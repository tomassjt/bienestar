import { Component } from '@angular/core';

@Component({
  selector: 'doc-icon',
  templateUrl: './doc-icon.component.html',
  styleUrls: ['./doc-icon.component.css']
})
export class DocIconComponent {

}
