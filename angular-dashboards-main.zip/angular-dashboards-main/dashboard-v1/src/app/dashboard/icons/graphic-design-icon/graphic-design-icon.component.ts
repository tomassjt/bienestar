import { Component } from '@angular/core';

@Component({
  selector: 'graphic-design-icon',
  templateUrl: './graphic-design-icon.component.html',
  styleUrls: ['./graphic-design-icon.component.css']
})
export class GraphicDesignIconComponent {

}
