import { Component } from '@angular/core';

@Component({
  selector: 'ux-icon',
  templateUrl: './ux-icon.component.html',
  styleUrls: ['./ux-icon.component.css']
})
export class UxIconComponent {

}
