import { Component } from '@angular/core';

@Component({
  selector: 'updates-icon',
  templateUrl: './updates-icon.component.html',
  styleUrls: ['./updates-icon.component.css']
})
export class UpdatesIconComponent {

}
