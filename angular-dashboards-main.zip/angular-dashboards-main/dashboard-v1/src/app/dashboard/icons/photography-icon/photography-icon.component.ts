import { Component } from '@angular/core';

@Component({
  selector: 'photography-icon',
  templateUrl: './photography-icon.component.html',
  styleUrls: ['./photography-icon.component.css']
})
export class PhotographyIconComponent {

}
