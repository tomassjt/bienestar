import { Component } from '@angular/core';

@Component({
  selector: 'illustration-icon',
  templateUrl: './illustration-icon.component.html',
  styleUrls: ['./illustration-icon.component.css']
})
export class IllustrationIconComponent {

}
