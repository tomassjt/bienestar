import { Component } from '@angular/core';

@Component({
  selector: 'video-icon',
  templateUrl: './video-icon.component.html',
  styleUrls: ['./video-icon.component.css']
})
export class VideoIconComponent {

}
