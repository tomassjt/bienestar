import { Component } from '@angular/core';

@Component({
  selector: 'apps-icon',
  templateUrl: './apps-icon.component.html',
  styleUrls: ['./apps-icon.component.css']
})
export class AppsIconComponent {

}
