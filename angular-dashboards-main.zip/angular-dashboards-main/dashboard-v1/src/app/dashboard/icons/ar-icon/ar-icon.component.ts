import { Component } from '@angular/core';

@Component({
  selector: 'ar-icon',
  templateUrl: './ar-icon.component.html',
  styleUrls: ['./ar-icon.component.css']
})
export class ArIconComponent {

}
