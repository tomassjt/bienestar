import { Component } from '@angular/core';

@Component({
  selector: 'doc',
  templateUrl: './doc.component.html',
  styleUrls: ['./doc.component.css']
})
export class DocComponent {

}
