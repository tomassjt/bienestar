import { Component } from '@angular/core';

@Component({
  selector: 'folder-icon',
  templateUrl: './folder-icon.component.html',
  styleUrls: ['./folder-icon.component.css']
})
export class FolderIconComponent {

}
