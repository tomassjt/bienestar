import { Component } from '@angular/core';

@Component({
  selector: 'credit-icon',
  templateUrl: './credit-icon.component.html',
  styleUrls: ['./credit-icon.component.css']
})
export class CreditIconComponent {

}
