import { Component } from '@angular/core';

@Component({
  selector: 'home-icon',
  templateUrl: './home-icon.component.html',
  styleUrls: ['./home-icon.component.css']
})
export class HomeIconComponent {

}
