import { Component } from '@angular/core';

@Component({
  selector: 'archive-icon',
  templateUrl: './archive-icon.component.html',
  styleUrls: ['./archive-icon.component.css']
})
export class ArchiveIconComponent {

}
