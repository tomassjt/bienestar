import { Component } from '@angular/core';

@Component({
  selector: 'app-time-manage',
  templateUrl: './time-manage.component.html',
  styleUrls: ['./time-manage.component.css']
})
export class TimeManageComponent {

}
