import { Component } from '@angular/core';

@Component({
  selector: 'settings-icon',
  templateUrl: './settings-icon.component.html',
  styleUrls: ['./settings-icon.component.css']
})
export class SettingsIconComponent {

}
