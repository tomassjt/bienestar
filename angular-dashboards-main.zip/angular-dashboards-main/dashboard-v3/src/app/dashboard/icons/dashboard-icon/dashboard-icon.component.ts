import { Component } from '@angular/core';

@Component({
  selector: 'dashboard-icon',
  templateUrl: './dashboard-icon.component.html',
  styleUrls: ['./dashboard-icon.component.css']
})
export class DashboardIconComponent {

}
