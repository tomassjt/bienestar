import { Component } from '@angular/core';

@Component({
  selector: 'report-icon',
  templateUrl: './report-icon.component.html',
  styleUrls: ['./report-icon.component.css']
})
export class ReportIconComponent {

}
