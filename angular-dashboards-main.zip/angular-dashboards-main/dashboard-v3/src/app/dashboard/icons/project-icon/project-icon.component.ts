import { Component } from '@angular/core';

@Component({
  selector: 'project-icon',
  templateUrl: './project-icon.component.html',
  styleUrls: ['./project-icon.component.css']
})
export class ProjectIconComponent {

}
