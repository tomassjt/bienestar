import { Component } from '@angular/core';

@Component({
  selector: 'calendar-icon',
  templateUrl: './calendar-icon.component.html',
  styleUrls: ['./calendar-icon.component.css']
})
export class CalendarIconComponent {

}
