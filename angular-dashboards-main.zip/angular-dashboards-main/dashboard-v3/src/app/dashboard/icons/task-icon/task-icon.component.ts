import { Component } from '@angular/core';

@Component({
  selector: 'task-icon',
  templateUrl: './task-icon.component.html',
  styleUrls: ['./task-icon.component.css']
})
export class TaskIconComponent {

}
