import { Component } from '@angular/core';

@Component({
  selector: 'time-manage-icon',
  templateUrl: './time-manage-icon.component.html',
  styleUrls: ['./time-manage-icon.component.css']
})
export class TimeManageIconComponent {

}
